package theniraj.tech.gemini_genius

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
